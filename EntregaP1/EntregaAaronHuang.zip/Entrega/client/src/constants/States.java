package constants;

/**
 * Created by aaron on 24/02/2015.
 */
public class States {
    public static final String VOID_STATE = "VOID";
    public static final String START_STATE = "START";
    public static final String ANTE_STATE = "ANTE";
    public static final String DRAW_STATE = "DRAW";
    public static final String PASS_STATE = "PASS";
}
