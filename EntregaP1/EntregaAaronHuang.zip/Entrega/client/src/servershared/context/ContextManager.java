package servershared.context;

/**
 * Created by aaron on 08/03/2015.
 */
public interface ContextManager {
    void runServer();
    void stopServer();
}
