package exceptions;

/**
 * Created by aaron on 12/03/2015.
 */
public class DeckException extends RuntimeException {
    public DeckException(String message) {
        super(message);
    }
}
