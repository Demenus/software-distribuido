package exceptions;

/**
 * Created by aaron on 24/02/2015.
 */
public enum ErrType {
    APPLICATION_ERROR,
    READ_ERROR,
    WRITE_ERROR,
    COMMAND_ERROR,
    PARSE_ERROR,
    STATE_ERROR,
    TIMEOUT_ERROR
}
